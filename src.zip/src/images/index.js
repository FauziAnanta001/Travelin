import Logo from './Logo.png'
import SplashBackground from './SplashBackground.png'

export{Logo,SplashBackground}