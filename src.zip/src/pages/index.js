import SignIn from './SignIn'
import Splash from './splash'
import Home from './Home' 
import CreateAccount from './CreateAccount'

export {Splash, SignIn,Home, CreateAccount}